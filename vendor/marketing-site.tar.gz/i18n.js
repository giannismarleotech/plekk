(()=>{
'use strict';
const lang=location.pathname.match(/^\/(nl|fr|de|en)(?:\/|$)/)?.[1]||'nl';
const locale={nl:'nl-BE',fr:'fr-BE',de:'de-BE',en:'en-GB'}[lang];
const dictionary=window.PLEKK_TRANSLATIONS?.[lang]||{};
const words={fr:['personnes','par mois hors TVA','Statut de','Statut modifié :','Commande déplacée vers','mention','mentions','dans la démo','Moins','Plus'],de:['Personen','Monat zzgl. MwSt.','Status von','Status geändert auf','Bestellung verschoben nach','Eintrag','Einträge','in der Demo','Weniger','Mehr'],en:['people','month excl. VAT','Status of','Status changed to','Order moved to','entry','entries','in the demo','Less','More']}[lang];
function t(value){
 const raw=String(value),s=raw.trim().replace(/\s+/g,' ');if(lang==='nl'||!s)return raw;
 let out=dictionary[s];
 if(out===undefined){
  const plain=s.replace(/^[←↗✓↻→]\s*|\s*[←↗✓↻→]$/g,'');
  if(plain!==s&&dictionary[plain])out=s.replace(plain,dictionary[plain]);
  else if(s.includes(' · '))out=s.split(' · ').map(t).join(' · ');
  else if(s.includes(' | '))out=s.split(' | ').map(t).join(' | ');
  else if(s.includes(', '))out=s.split(', ').map(t).join(', ');
  else if(/^\d+ × /.test(s))out=s.replace(/^(\d+ × )(.*)$/,(_,n,d)=>n+t(d));
  else if(/^[\d–]+ personen$/.test(s))out=s.replace('personen',words[0]);
  else if(/^\d+ vermeldingen? in de demo$/.test(s))out=s.replace(/vermeldingen?/,s.startsWith('1 ')?words[5]:words[6]).replace('in de demo',words[7]);
  else if(s.includes('/maand excl. btw'))out=s.replace('/maand excl. btw','/'+words[1]);
  else for(const [prefix,index] of [['Status van ',2],['Status aangepast naar ',3],['Bestelling verplaatst naar ',4],['Minder ',8],['Meer ',9]])if(s.startsWith(prefix)){out=words[index]+' '+t(s.slice(prefix.length));break;}
 }
 return out===undefined?raw:raw.slice(0,raw.indexOf(raw.trim()))+out+raw.slice(raw.indexOf(raw.trim())+raw.trim().length);
}
function path(url){return url.replace(/^\/(?:nl|fr|de|en)(?=\/|$)/,'/'+lang)}
const textSkip='script,style,textarea,code,pre,.message-preview,#preview-name,#preview-city,.record-name';
function apply(root){
 if(!root)return;
 if(root.nodeType===3){if(!root.parentElement?.closest(textSkip)){const value=t(root.nodeValue);if(value!==root.nodeValue)root.nodeValue=value}return}
 if(root.nodeType!==1&&root.nodeType!==9)return;
 const nodes=root.nodeType===1?[root,...root.querySelectorAll('*')]:[...root.querySelectorAll('*')];
 for(const el of nodes){
  if(el.closest(textSkip))continue;
  // Keep stored business/status values independent from the display language.
  if(el.tagName==='OPTION'&&!el.hasAttribute('value'))el.setAttribute('value',el.textContent);
  for(const attr of ['aria-label','placeholder','alt','title'])if(el.hasAttribute(attr)){const v=el.getAttribute(attr),next=t(v);if(next!==v)el.setAttribute(attr,next)}
  if(el.matches('meta[name="description"]')){const v=t(el.content);if(v!==el.content)el.content=v}
  if(el.matches('a[href]')&&!el.closest('.language-picker')){const v=el.getAttribute('href'),next=path(v);if(next!==v)el.setAttribute('href',next)}
  for(const child of el.childNodes)if(child.nodeType===3){const v=t(child.nodeValue);if(v!==child.nodeValue)child.nodeValue=v}
 }
}
function contactMessage(name,business,type,message){const types=t(type);return ({nl:`Hallo Giannis,\n\nMijn naam is ${name} en mijn zaak heet ${business}.\nType zaak: ${types}.\n\n${message}\n\nGroeten,\n${name}`,fr:`Bonjour Giannis,\n\nJe m’appelle ${name} et mon commerce s’appelle ${business}.\nType de commerce : ${types}.\n\n${message}\n\nCordialement,\n${name}`,de:`Hallo Giannis,\n\nIch heiße ${name} und mein Betrieb heißt ${business}.\nBetriebsart: ${types}.\n\n${message}\n\nViele Grüße\n${name}`,en:`Hello Giannis,\n\nMy name is ${name} and my business is called ${business}.\nBusiness type: ${types}.\n\n${message}\n\nBest regards,\n${name}`})[lang]}
function confirmation(guest,business,day,time,total){return ({nl:`${guest}, zo zou je bevestiging bij <strong>${business}</strong> eruitzien: <strong>${day} om ${time}</strong>${total?`, voor ${total}`:''}.`,fr:`${guest}, voici votre exemple de confirmation chez <strong>${business}</strong> : <strong>${day} à ${time}</strong>${total?`, pour ${total}`:''}.`,de:`${guest}, so würde deine Bestätigung bei <strong>${business}</strong> aussehen: <strong>${day} um ${time}</strong>${total?`, für ${total}`:''}.`,en:`${guest}, here is your example confirmation for <strong>${business}</strong>: <strong>${day} at ${time}</strong>${total?`, for ${total}`:''}.`})[lang]}
window.PlekkI18n={lang,locale,t,path,apply,contactMessage,confirmation,contactSubject:({nl:'Kennismaken met Plekk',fr:'Découvrir Plekk',de:'Plekk kennenlernen',en:'Get to know Plekk'})[lang],interest:topic=>({nl:`Ik wil graag meer weten over ${topic}. Mijn situatie: `,fr:`Je souhaite en savoir plus sur ${topic}. Ma situation : `,de:`Ich möchte mehr über ${topic} erfahren. Meine Situation: `,en:`I would like to know more about ${topic}. My situation: `})[lang]};
document.documentElement.lang=lang;
document.addEventListener('DOMContentLoaded',()=>{
 const picker=document.querySelector('#site-language');if(picker){picker.value=lang;picker.addEventListener('change',()=>{const prefix=location.pathname==='/'?'/nl/':location.pathname;location.assign(prefix.replace(/^\/(nl|fr|de|en)/,'/'+picker.value)+location.search+location.hash)})}
 apply(document);
 new MutationObserver(ms=>{for(const m of ms){if(m.type==='characterData')apply(m.target);else if(m.type==='attributes')apply(m.target);else for(const n of m.addedNodes)apply(n)}}).observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['aria-label','placeholder','alt','title','content','href']});
});
})();
